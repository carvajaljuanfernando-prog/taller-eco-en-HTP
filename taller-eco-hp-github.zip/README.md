# Lectura guiada del eco en hipertensión pulmonar

Taller interactivo para médicos: cuatro casos clínicos ficticios que arrancan con el informe de ecocardiograma tal como sale del laboratorio y se analizan con cinco preguntas guiadas (presión, probabilidad, ventrículo derecho, origen y seguimiento).

Autor: Dr. Juan Fernando Carvajal Estupiñán · Programa de Hipertensión Pulmonar, Instituto Neumológico del Oriente.

## Publicar en GitHub Pages

1. Cree un repositorio nuevo en GitHub (por ejemplo `taller-eco-hp`).
2. Suba `index.html` y este `README.md` a la rama `main`.
3. En el repositorio: **Settings → Pages → Build and deployment → Source: Deploy from a branch → Branch: main / (root) → Save**.
4. En uno o dos minutos el taller queda en `https://<su-usuario>.github.io/taller-eco-hp/`.

No necesita compilación ni dependencias: es un solo archivo HTML con las fuentes cargadas desde Google Fonts. El progreso y las preferencias (modo facilitador, proyector) se guardan en el navegador de cada asistente.

## Uso en el taller

- **Modo facilitador**: marca la respuesta correcta y muestra notas de conducción para cada pregunta.
- **Proyector**: aumenta el tamaño de letra.
- Flechas ← → del teclado para avanzar y retroceder.

Los casos y valores son construidos con fines docentes y no corresponden a pacientes reales.
